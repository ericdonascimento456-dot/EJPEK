<?php
require('conexao.php');

// Obtém e valida o ID (apenas inteiros positivos)
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$id) {
    header('Location: index.php?msg=erro');
    exit();
}

try {
    // Verifica se o usuário existe antes de deletar
    $check = $pdo->prepare("SELECT id FROM cadastro WHERE id = :id LIMIT 1");
    $check->execute([':id' => $id]);

    if (!$check->fetch()) {
        header('Location: index.php?msg=erro');
        exit();
    }

    // Deleta o registro
    $stmt = $pdo->prepare("DELETE FROM cadastro WHERE id = :id");
    $stmt->execute([':id' => $id]);

    header('Location: index.php?msg=deletado');
    exit();

} catch (PDOException $e) {
    error_log("Erro ao deletar: " . $e->getMessage());
    header('Location: index.php?msg=erro');
    exit();
}
