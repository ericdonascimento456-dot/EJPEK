<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'crudphp');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

$dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,   // Lança exceções em erros
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,         // Retorna arrays associativos
    PDO::ATTR_EMULATE_PREPARES   => false,                    // Prepared statements reais
];

try {
    $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
} catch (PDOException $e) {
    // Em produção, NUNCA exponha detalhes do erro ao usuário
    error_log("Erro de conexão: " . $e->getMessage());
    die(json_encode(['erro' => 'Falha na conexão com o banco de dados.']));
}
