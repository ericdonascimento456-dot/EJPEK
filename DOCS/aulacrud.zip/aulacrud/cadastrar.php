<?php
require('conexao.php');

// Aceita apenas POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit();
}

// Sanitiza e valida entradas
$nome      = trim(filter_input(INPUT_POST, 'nome',      FILTER_SANITIZE_SPECIAL_CHARS));
$sobrenome = trim(filter_input(INPUT_POST, 'sobrenome', FILTER_SANITIZE_SPECIAL_CHARS));
$datanasc  = filter_input(INPUT_POST, 'datanasc', FILTER_SANITIZE_SPECIAL_CHARS);

// Validações básicas
if (empty($nome) || empty($sobrenome) || empty($datanasc)) {
    header('Location: form.php?erro=campos_vazios');
    exit();
}

// Valida formato da data (YYYY-MM-DD)
$data = DateTime::createFromFormat('Y-m-d', $datanasc);
if (!$data || $data->format('Y-m-d') !== $datanasc) {
    header('Location: form.php?erro=data_invalida');
    exit();
}

try {
    $sql  = "INSERT INTO cadastro (nome, sobrenome, datanasc) VALUES (:nome, :sobrenome, :datanasc)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nome'      => $nome,
        ':sobrenome' => $sobrenome,
        ':datanasc'  => $datanasc,
    ]);

    header('Location: index.php?msg=cadastrado');
    exit();

} catch (PDOException $e) {
    error_log("Erro ao cadastrar: " . $e->getMessage());
    header('Location: index.php?msg=erro');
    exit();
}
