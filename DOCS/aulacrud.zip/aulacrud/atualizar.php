<?php
require('conexao.php');

// Aceita apenas POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit();
}

// Valida e sanitiza entradas
$id        = filter_input(INPUT_POST, 'id',        FILTER_VALIDATE_INT);
$nome      = trim(filter_input(INPUT_POST, 'nome',      FILTER_SANITIZE_SPECIAL_CHARS));
$sobrenome = trim(filter_input(INPUT_POST, 'sobrenome', FILTER_SANITIZE_SPECIAL_CHARS));
$datanasc  = filter_input(INPUT_POST, 'datanasc', FILTER_SANITIZE_SPECIAL_CHARS);

// Validações
if (!$id || empty($nome) || empty($sobrenome) || empty($datanasc)) {
    header('Location: index.php?msg=erro');
    exit();
}

// Valida formato da data
$data = DateTime::createFromFormat('Y-m-d', $datanasc);
if (!$data || $data->format('Y-m-d') !== $datanasc) {
    header('Location: form.php?id=' . $id . '&erro=data_invalida');
    exit();
}

try {
    $sql  = "UPDATE cadastro SET nome = :nome, sobrenome = :sobrenome, datanasc = :datanasc WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nome'      => $nome,
        ':sobrenome' => $sobrenome,
        ':datanasc'  => $datanasc,
        ':id'        => $id,
    ]);

    header('Location: index.php?msg=atualizado');
    exit();

} catch (PDOException $e) {
    error_log("Erro ao atualizar: " . $e->getMessage());
    header('Location: index.php?msg=erro');
    exit();
}
