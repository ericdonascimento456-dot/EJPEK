<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD PHP — Formulário</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --bg:       #0d0f14;
            --surface:  #161920;
            --border:   #252830;
            --accent:   #00e5a0;
            --accent2:  #007aff;
            --danger:   #ff4757;
            --text:     #e8eaf0;
            --muted:    #6b7080;
            --radius:   12px;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem 1rem;
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(var(--border) 1px, transparent 1px),
                linear-gradient(90deg, var(--border) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: 0.4;
            pointer-events: none;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            width: 100%;
            max-width: 480px;
            padding: 2.5rem;
            position: relative;
            z-index: 1;
            animation: fadeUp .4s ease both;
        }

        @keyframes fadeUp {
            from { opacity: 0; transform: translateY(16px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .card-title {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 1.5rem;
            margin-bottom: .4rem;
            letter-spacing: -.02em;
        }

        .card-title span { color: var(--accent); }

        .card-sub {
            color: var(--muted);
            font-size: .875rem;
            margin-bottom: 2rem;
        }

        .field { margin-bottom: 1.25rem; }

        label {
            display: block;
            font-size: .78rem;
            font-weight: 600;
            letter-spacing: .06em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: .45rem;
        }

        input[type="text"],
        input[type="date"] {
            width: 100%;
            background: rgba(255,255,255,.04);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
            font-size: .95rem;
            padding: .75rem 1rem;
            outline: none;
            transition: border-color .2s, box-shadow .2s;
            -webkit-appearance: none;
        }

        input[type="text"]:focus,
        input[type="date"]:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(0,229,160,.15);
        }

        /* Corrige a cor do calendário no dark mode */
        input[type="date"]::-webkit-calendar-picker-indicator {
            filter: invert(0.7);
            cursor: pointer;
        }

        .form-actions {
            display: flex;
            gap: .75rem;
            margin-top: 2rem;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: .5rem;
            padding: .75rem 1.4rem;
            border-radius: 8px;
            font-family: 'DM Sans', sans-serif;
            font-size: .95rem;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: opacity .2s, transform .15s;
            text-decoration: none;
            flex: 1;
        }
        .btn:hover  { opacity: .85; transform: translateY(-1px); }
        .btn:active { transform: translateY(0); }

        .btn-primary { background: var(--accent);  color: #0d0f14; }
        .btn-outline { background: transparent; border: 1px solid var(--border); color: var(--text); }
    </style>
</head>
<body>
<div class="card">
    <?php
    require('conexao.php');

    $id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $usuario = null;
    $editando = false;

    if ($id) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM cadastro WHERE id = :id LIMIT 1");
            $stmt->execute([':id' => $id]);
            $usuario = $stmt->fetch();
            if ($usuario) $editando = true;
        } catch (PDOException $e) {
            error_log($e->getMessage());
        }
    }

    $acao  = $editando ? 'Editar' : 'Novo';
    $destino = $editando ? 'atualizar.php' : 'cadastrar.php';
    ?>

    <h1 class="card-title"><?= $acao ?> <span>usuário</span></h1>
    <p class="card-sub"><?= $editando ? 'Altere os dados e salve.' : 'Preencha os campos abaixo.' ?></p>

    <form action="<?= $destino ?>" method="post" novalidate>

        <?php if ($editando): ?>
            <input type="hidden" name="id" value="<?= (int)$usuario['id'] ?>">
        <?php endif; ?>

        <div class="field">
            <label for="nome">Nome</label>
            <input type="text" id="nome" name="nome"
                   placeholder="Ex: Maria"
                   maxlength="100"
                   value="<?= htmlspecialchars($usuario['nome'] ?? '') ?>"
                   required>
        </div>

        <div class="field">
            <label for="sobrenome">Sobrenome</label>
            <input type="text" id="sobrenome" name="sobrenome"
                   placeholder="Ex: Silva"
                   maxlength="100"
                   value="<?= htmlspecialchars($usuario['sobrenome'] ?? '') ?>"
                   required>
        </div>

        <div class="field">
            <label for="datanasc">Data de nascimento</label>
            <input type="date" id="datanasc" name="datanasc"
                   value="<?= htmlspecialchars($usuario['datanasc'] ?? '') ?>"
                   required>
        </div>

        <div class="form-actions">
            <a href="index.php" class="btn btn-outline">Cancelar</a>
            <button type="submit" class="btn btn-primary">
                <?= $editando ? 'Salvar alterações' : 'Cadastrar' ?>
            </button>
        </div>

    </form>
</div>
</body>
</html>
