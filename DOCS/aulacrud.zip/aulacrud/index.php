<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD PHP — Usuários</title>
    <link href="https://fonts.googleapis.com/css2?family=Syne:wght@400;600;800&family=DM+Sans:ital,wght@0,300;0,400;0,500;1,300&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --bg:        #0d0f14;
            --surface:   #161920;
            --border:    #252830;
            --accent:    #00e5a0;
            --accent2:   #007aff;
            --danger:    #ff4757;
            --text:      #e8eaf0;
            --muted:     #6b7080;
            --radius:    12px;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'DM Sans', sans-serif;
            min-height: 100vh;
            padding: 2rem 1rem;
        }

        /* Fundo com grade sutil */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(var(--border) 1px, transparent 1px),
                linear-gradient(90deg, var(--border) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: 0.4;
            pointer-events: none;
            z-index: 0;
        }

        .container {
            max-width: 900px;
            margin: 0 auto;
            position: relative;
            z-index: 1;
        }

        /* ── Header ── */
        header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 2.5rem;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .logo {
            font-family: 'Syne', sans-serif;
            font-weight: 800;
            font-size: 1.8rem;
            letter-spacing: -0.03em;
        }

        .logo span {
            color: var(--accent);
        }

        .btn {
            display: inline-flex;
            align-items: center;
            gap: .5rem;
            padding: .6rem 1.3rem;
            border-radius: 8px;
            font-family: 'DM Sans', sans-serif;
            font-size: .9rem;
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: opacity .2s, transform .15s;
            text-decoration: none;
        }
        .btn:hover { opacity: .85; transform: translateY(-1px); }
        .btn:active { transform: translateY(0); }

        .btn-primary  { background: var(--accent);  color: #0d0f14; }
        .btn-edit     { background: var(--accent2); color: #fff; font-size: .8rem; padding: .4rem .9rem; }
        .btn-danger   { background: var(--danger);  color: #fff; font-size: .8rem; padding: .4rem .9rem; }
        .btn-outline  { background: transparent; border: 1px solid var(--border); color: var(--text); }

        /* ── Mensagens ── */
        .alert {
            padding: .85rem 1.2rem;
            border-radius: var(--radius);
            margin-bottom: 1.5rem;
            font-size: .9rem;
            font-weight: 500;
        }
        .alert-success { background: rgba(0,229,160,.12); border: 1px solid var(--accent);  color: var(--accent); }
        .alert-error   { background: rgba(255,71,87,.12);  border: 1px solid var(--danger);  color: var(--danger); }

        /* ── Tabela ── */
        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: var(--radius);
            overflow: hidden;
        }

        .card-header {
            padding: 1.2rem 1.5rem;
            border-bottom: 1px solid var(--border);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        .card-title {
            font-family: 'Syne', sans-serif;
            font-weight: 600;
            font-size: 1rem;
        }

        .badge {
            background: rgba(0,229,160,.15);
            color: var(--accent);
            font-size: .75rem;
            font-weight: 600;
            padding: .25rem .7rem;
            border-radius: 99px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        thead th {
            padding: .85rem 1.5rem;
            text-align: left;
            font-size: .75rem;
            font-weight: 600;
            letter-spacing: .08em;
            text-transform: uppercase;
            color: var(--muted);
            background: rgba(255,255,255,.02);
        }

        tbody tr {
            border-top: 1px solid var(--border);
            transition: background .15s;
        }
        tbody tr:hover { background: rgba(255,255,255,.025); }

        tbody td {
            padding: 1rem 1.5rem;
            font-size: .9rem;
            vertical-align: middle;
        }

        .td-id {
            color: var(--muted);
            font-family: monospace;
            font-size: .8rem;
        }

        .actions { display: flex; gap: .5rem; }

        /* Estado vazio */
        .empty-state {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--muted);
        }
        .empty-state svg { margin-bottom: 1rem; opacity: .4; }
        .empty-state p { font-size: .95rem; }

        /* Responsivo */
        @media (max-width: 600px) {
            table thead { display: none; }
            table tbody tr { display: block; padding: 1rem 1.5rem; }
            table tbody td { display: block; padding: .25rem 0; }
            table tbody td::before {
                content: attr(data-label) ': ';
                font-weight: 600;
                color: var(--muted);
                font-size: .75rem;
                text-transform: uppercase;
                letter-spacing: .05em;
            }
            .actions { margin-top: .5rem; }
        }
    </style>
</head>
<body>
<div class="container">

    <header>
        <div class="logo">crud<span>php</span></div>
        <a href="form.php" class="btn btn-primary">
            <svg width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" viewBox="0 0 24 24"><path d="M12 5v14M5 12h14"/></svg>
            Novo usuário
        </a>
    </header>

    <?php
    require('conexao.php');

    // Mensagens de feedback via query string
    $msg = filter_input(INPUT_GET, 'msg', FILTER_SANITIZE_SPECIAL_CHARS);
    if ($msg === 'cadastrado')  echo '<div class="alert alert-success">✓ Usuário cadastrado com sucesso!</div>';
    if ($msg === 'atualizado')  echo '<div class="alert alert-success">✓ Usuário atualizado com sucesso!</div>';
    if ($msg === 'deletado')    echo '<div class="alert alert-success">✓ Usuário removido com sucesso!</div>';
    if ($msg === 'erro')        echo '<div class="alert alert-error">✗ Ocorreu um erro. Tente novamente.</div>';

    try {
        $stmt = $pdo->query("SELECT * FROM cadastro ORDER BY id DESC");
        $usuarios = $stmt->fetchAll();
    } catch (PDOException $e) {
        error_log($e->getMessage());
        $usuarios = [];
    }
    ?>

    <div class="card">
        <div class="card-header">
            <span class="card-title">Usuários cadastrados</span>
            <span class="badge"><?= count($usuarios) ?> registros</span>
        </div>

        <?php if (empty($usuarios)): ?>
            <div class="empty-state">
                <svg width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/>
                    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>
                </svg>
                <p>Nenhum usuário cadastrado ainda.</p>
            </div>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nome</th>
                        <th>Sobrenome</th>
                        <th>Data de Nasc.</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $u): ?>
                    <tr>
                        <td class="td-id" data-label="ID"><?= htmlspecialchars($u['id']) ?></td>
                        <td data-label="Nome"><?= htmlspecialchars($u['nome']) ?></td>
                        <td data-label="Sobrenome"><?= htmlspecialchars($u['sobrenome']) ?></td>
                        <td data-label="Nasc."><?= htmlspecialchars(date('d/m/Y', strtotime($u['datanasc']))) ?></td>
                        <td data-label="Ações">
                            <div class="actions">
                                <a href="form.php?id=<?= (int)$u['id'] ?>" class="btn btn-edit">Editar</a>
                                <a href="deletar.php?id=<?= (int)$u['id'] ?>"
                                   class="btn btn-danger"
                                   onclick="return confirm('Tem certeza que deseja excluir este usuário?')">Excluir</a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>

</div>
</body>
</html>
